import java.util.*;
public class Sistem {
    public Registry registry;
    public ArrayList<Pelanggan> pelanggans;
    public ArrayList<Properti> properties;
    public Sistem(){
        this.registry = new Registry();
        this.pelanggans = new ArrayList<Pelanggan>();
        this.properties = new ArrayList<Properti>();
    }
    
    

}