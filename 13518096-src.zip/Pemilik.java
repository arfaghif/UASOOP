
public class Pemilik {
    private String nama;
    public Pemilik(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return this.nama;
    }
}