import java.util.*;
public class Registry {
    public ArrayList<Pemilik> pemiliks;
    public Registry(){
        pemiliks = new ArrayList<Pemilik>();
    }


}