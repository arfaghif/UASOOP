#  UAS
## How to Compile
javac Properti.java Apartemen.java Hotel.java HomeStay.java TipeKamar.java BroadCast.java Fasilitas.java Pelanggan.java Pemilik.java Registry.java Sistem.java Main.java


## How to Run
java Main

## Pattern yang dipilih 
Singleton : Sistem hanya satu yang diimplementasikan dengan kelas sistem
Observer : digunakan pada saat broad cast
