public enum TipeKamar {
    standard, deluxe, suite
}